#!/usr/bin/env bash
set -euo pipefail
python -m pip install -r requirements.txt
python -m pytest -q
python -m src.pipeline --output outputs "$@"
