import numpy as np
import pytest
from src.decision_protocol import (automated_decision, binary_entropy, disagreement,
    ensemble_probability, final_decision, review_assignment)

P=np.array([[.1,.2,.3],[.8,.7,.9],[0.,0.,0.]])

def test_ensemble_and_disagreement():
    np.testing.assert_allclose(ensemble_probability(P),[.2,.8,0.])
    np.testing.assert_allclose(disagreement(P),[np.std([.1,.2,.3]),np.std([.8,.7,.9]),0.])

def test_entropy_boundaries():
    e=binary_entropy(np.array([0.,.5,1.]))
    assert e[0]==0 and e[2]==0 and e[1]>0

def test_policy_and_final_decision():
    r=review_assignment(P,.15,.25,.5)
    assert r.tolist()==[True,False,False]
    a=automated_decision(P,.5)
    out=final_decision(a,r,np.array([1,0,1]))
    assert out.tolist()==[1,1,0]

def test_invalid_probability_rejected():
    with pytest.raises(ValueError): ensemble_probability(np.array([[1.2,.2]]))

def test_review_policy_validates_bounds():
    with pytest.raises(ValueError): review_assignment(P, .8, .2, .1)
