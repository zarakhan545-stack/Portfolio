"""Reproducible training, policy selection, and evaluation for the study.

The reviewer is simulated from declared sensitivity/specificity assumptions.
No claim is made that these values represent real human reviewers.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
from sklearn.calibration import CalibratedClassifierCV
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (average_precision_score, brier_score_loss,
                             confusion_matrix, f1_score, precision_score,
                             recall_score, roc_auc_score)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

SEED = 42
FEATURE_TARGETS = ("Class", "class", "target", "Target")


def load_dataset(path: str | None = None) -> tuple[pd.DataFrame, str]:
    """Load local Kaggle CSV or fetch OpenML data_id=1597 (network required)."""
    if path:
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"Dataset not found: {p}")
        df = pd.read_csv(p)
        source = str(p.resolve())
    else:
        from sklearn.datasets import fetch_openml
        bunch = fetch_openml(data_id=1597, as_frame=True, parser="auto")
        df = bunch.frame.copy()
        source = "OpenML data_id=1597 (ULB/Worldline credit-card fraud dataset)"
    target = next((c for c in FEATURE_TARGETS if c in df.columns), None)
    if target is None:
        raise ValueError(f"Target column not found. Columns: {list(df.columns)}")
    if target != "Class":
        df = df.rename(columns={target: "Class"})
    df["Class"] = pd.to_numeric(df["Class"], errors="raise").astype(int)
    if set(df["Class"].unique()) != {0, 1}:
        raise ValueError("Class must contain exactly the binary labels 0 and 1")
    df = df.replace([np.inf, -np.inf], np.nan)
    non_numeric = [c for c in df.columns if c != "Class" and not pd.api.types.is_numeric_dtype(df[c])]
    if non_numeric:
        raise ValueError(f"Unexpected non-numeric predictors: {non_numeric}")
    return df, source


def dataset_fingerprint(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def split_data(df: pd.DataFrame, seed: int = SEED):
    """Stratified 60/15/25 split; no fitting or resampling occurs here."""
    X = df.drop(columns="Class")
    y = df["Class"].to_numpy()
    X_train, X_temp, y_train, y_temp = train_test_split(
        X, y, test_size=0.40, stratify=y, random_state=seed)
    # 15% validation and 25% test of total = 37.5% / 62.5% of temp.
    X_val, X_test, y_val, y_test = train_test_split(
        X_temp, y_temp, test_size=0.625, stratify=y_temp, random_state=seed)
    return X_train, X_val, X_test, y_train, y_val, y_test


def build_models(seed: int = SEED):
    """Three diverse probabilistic agents; calibration uses training folds only."""
    base = {
        "logistic_regression": Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scale", StandardScaler()),
            ("model", LogisticRegression(class_weight="balanced", max_iter=2000,
                                          solver="lbfgs", random_state=seed)),
        ]),
        "random_forest": Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", RandomForestClassifier(n_estimators=300, min_samples_leaf=2,
                class_weight="balanced_subsample", n_jobs=-1, random_state=seed)),
        ]),
        "hist_gradient_boosting": Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", HistGradientBoostingClassifier(max_iter=180, learning_rate=0.08,
                l2_regularization=1.0, class_weight="balanced", random_state=seed)),
        ]),
    }
    return {name: CalibratedClassifierCV(estimator=est, method="sigmoid", cv=3)
            for name, est in base.items()}


def probability_matrix(models, X: pd.DataFrame, fit_y=None) -> np.ndarray:
    cols = []
    for model in models.values():
        if fit_y is not None:
            model.fit(X, fit_y)
        cols.append(model.predict_proba(X)[:, 1])
    return np.column_stack(cols)


def entropy(p: np.ndarray) -> np.ndarray:
    p = np.clip(np.asarray(p, dtype=float), 1e-12, 1 - 1e-12)
    return -(p * np.log(p) + (1 - p) * np.log(1 - p))


def expected_confusion(y: np.ndarray, automated: np.ndarray, review: np.ndarray,
                       q1: float, q0: float) -> np.ndarray:
    """Expected [TN, FP, FN, TP] counts under the declared reviewer SCM."""
    y = np.asarray(y, dtype=int)
    final_positive_prob = np.where(review, np.where(y == 1, q1, 1 - q0), automated)
    return np.array([
        np.sum((y == 0) * (1 - final_positive_prob)),
        np.sum((y == 0) * final_positive_prob),
        np.sum((y == 1) * (1 - final_positive_prob)),
        np.sum((y == 1) * final_positive_prob),
    ], dtype=float)


def scores_from_cm(cm: Iterable[float]) -> dict:
    tn, fp, fn, tp = np.asarray(cm, dtype=float)
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    return {"tn": float(tn), "fp": float(fp), "fn": float(fn), "tp": float(tp),
            "precision": float(precision), "recall": float(recall),
            "f1": float(2 * precision * recall / (precision + recall)) if precision + recall else 0.0,
            "fpr": float(fp / (fp + tn)) if fp + tn else 0.0}


def choose_policy(P: np.ndarray, y: np.ndarray, review_budget: float = .10,
                  recall_floor: float = .80, c_fp: float = 1.0,
                  c_fn: float = 10.0, c_review: float = .5,
                  q1: float = .90, q0: float = .95) -> dict:
    """Select combined policy on validation only; infeasibility is explicit."""
    mean = P.mean(axis=1)
    spread = P.std(axis=1, ddof=0)
    qs = [0.50, 0.70, 0.80, 0.90, 0.95, 0.98, 0.99]
    candidates = []
    for t in [.05, .10, .20, .30, .40, .50, .60, .70, .80, .90]:
        auto = (mean >= t).astype(int)
        for lq in qs:
            lower = float(np.quantile(mean, lq))
            for uq in qs:
                upper = float(np.quantile(mean, uq))
                if lower > upper:
                    continue
                for dq in qs:
                    delta = float(np.quantile(spread, dq))
                    review = ((mean >= lower) & (mean <= upper)) | (spread >= delta)
                    rate = float(review.mean())
                    if rate > review_budget:
                        continue
                    cm = expected_confusion(y, auto, review, q1, q0)
                    m = scores_from_cm(cm)
                    if m["recall"] + 1e-12 < recall_floor:
                        continue
                    cost = c_fp * m["fp"] + c_fn * m["fn"] + c_review * int(review.sum())
                    candidates.append((cost, rate, t, lower, upper, delta, m))
    if not candidates:
        return {"feasible": False, "reason": "No validation policy met both review-budget and recall constraints.",
                "review_budget": review_budget, "recall_floor": recall_floor}
    candidates.sort(key=lambda z: (z[0], z[1], z[2]))
    cost, rate, t, lower, upper, delta, metrics = candidates[0]
    return {"feasible": True, "threshold": t, "lower": lower, "upper": upper,
            "disagreement_threshold": delta, "validation_review_rate": rate,
            "validation_expected_cost": float(cost), "validation_expected_metrics": metrics,
            "review_budget": review_budget, "recall_floor": recall_floor,
            "costs": {"false_positive": c_fp, "false_negative": c_fn, "review": c_review},
            "reviewer_assumptions": {"sensitivity": q1, "specificity": q0}}


def simulate_final(P: np.ndarray, y: np.ndarray, policy: dict, q1: float, q0: float,
                   seeds: range = range(30), c_fp: float = 1., c_fn: float = 10.,
                   c_review: float = .5) -> dict:
    mean = P.mean(axis=1)
    spread = P.std(axis=1, ddof=0)
    auto = (mean >= policy["threshold"]).astype(int)
    review = ((mean >= policy["lower"]) & (mean <= policy["upper"])) | (spread >= policy["disagreement_threshold"])
    rows = []
    for seed in seeds:
        rng = np.random.default_rng(seed)
        reviewer = np.where(y == 1, rng.random(len(y)) < q1, rng.random(len(y)) >= q0).astype(int)
        final = np.where(review, reviewer, auto)
        tn, fp, fn, tp = confusion_matrix(y, final, labels=[0, 1]).ravel()
        row = scores_from_cm([tn, fp, fn, tp])
        row["review_rate"] = float(review.mean())
        row["cost"] = float(c_fp * fp + c_fn * fn + c_review * review.sum())
        rows.append(row)
    frame = pd.DataFrame(rows)
    return {"simulation_repeats": len(frame), "review_rate": float(review.mean()),
            "metrics_mean": frame.mean().to_dict(),
            "metrics_sd": frame.std(ddof=1).fillna(0).to_dict(),
            "metrics_95pct": {c: [float(frame[c].quantile(.025)), float(frame[c].quantile(.975))]
                              for c in frame.columns}}


def baseline_policy(P: np.ndarray, y: np.ndarray, kind: str, budget: float,
                    recall_floor: float, q1: float, q0: float,
                    c_fp: float, c_fn: float, c_review: float) -> dict:
    mean = P.mean(axis=1)
    spread = P.std(axis=1, ddof=0)
    if kind == "entropy":
        signal = entropy(mean)
    elif kind == "disagreement":
        signal = spread
    else:
        raise ValueError(kind)
    # Threshold candidates correspond to validation quantiles; review top-ranked cases.
    best = None
    for t in [.05, .1, .2, .3, .4, .5, .6, .7, .8, .9]:
        auto = (mean >= t).astype(int)
        for q in np.linspace(max(0, 1 - budget), 1, 16):
            cut = float(np.quantile(signal, q))
            review = signal >= cut
            cm = expected_confusion(y, auto, review, q1, q0)
            m = scores_from_cm(cm)
            if review.mean() > budget + 1e-9 or m["recall"] < recall_floor:
                continue
            cost = c_fp*m["fp"] + c_fn*m["fn"] + c_review*review.sum()
            if best is None or cost < best[0]:
                best = (cost, t, cut, m)
    if best is None:
        return {"feasible": False, "reason": f"No feasible {kind}-only validation policy."}
    return {"feasible": True, "threshold": best[1], "signal_threshold": best[2],
            "validation_expected_cost": float(best[0]), "validation_expected_metrics": best[3]}



def stratified_bootstrap_metrics(y: np.ndarray, probability: np.ndarray,
                                n_boot: int = 300, seed: int = SEED) -> dict:
    """Percentile CIs for ranking/calibration metrics, resampling each class separately."""
    y = np.asarray(y, dtype=int); p = np.asarray(probability, dtype=float)
    neg = np.flatnonzero(y == 0); pos = np.flatnonzero(y == 1)
    if len(neg) == 0 or len(pos) == 0:
        return {"error": "Both classes are required for stratified bootstrap."}
    rng = np.random.default_rng(seed); values = {"average_precision": [], "roc_auc": [], "brier": []}
    for _ in range(n_boot):
        idx = np.concatenate([rng.choice(neg, len(neg), replace=True),
                              rng.choice(pos, len(pos), replace=True)])
        yy, pp = y[idx], p[idx]
        values["average_precision"].append(average_precision_score(yy, pp))
        values["roc_auc"].append(roc_auc_score(yy, pp))
        values["brier"].append(brier_score_loss(yy, pp))
    return {metric: [float(np.quantile(vals, .025)), float(np.quantile(vals, .975))]
            for metric, vals in values.items()}



def fixed_policy_sensitivity(P: np.ndarray, y: np.ndarray, policy: dict,
                             review_budget: float) -> list[dict]:
    """Evaluate the frozen validation-selected policy under alternative assumptions."""
    mean = P.mean(axis=1); spread = P.std(axis=1, ddof=0)
    automated = (mean >= policy["threshold"]).astype(int)
    review = ((mean >= policy["lower"]) & (mean <= policy["upper"])) | (spread >= policy["disagreement_threshold"])
    rows = []
    for q1, q0 in ((.70,.80),(.85,.90),(.95,.98)):
        cm = expected_confusion(y, automated, review, q1, q0)
        m = scores_from_cm(cm)
        for c_fn in (5.0, 10.0, 20.0):
            cost = 1.0*m["fp"] + c_fn*m["fn"] + .5*int(review.sum())
            for capacity in (.05, review_budget, .15):
                rows.append({"reviewer_sensitivity":q1,"reviewer_specificity":q0,
                    "false_negative_cost":c_fn,"review_capacity":capacity,
                    "observed_policy_review_rate":float(review.mean()),
                    "within_review_capacity":bool(review.mean() <= capacity + 1e-12),
                    "recall":m["recall"],"expected_cost":float(cost)})
    return rows

def run(args):
    out = Path(args.output); out.mkdir(parents=True, exist_ok=True)
    df, source = load_dataset(args.data)
    initial_rows = len(df)
    duplicate_rows = int(df.duplicated().sum())
    # Remove exact duplicate records before splitting to reduce identical-row leakage.
    df = df.drop_duplicates().reset_index(drop=True)
    Xtr, Xv, Xte, ytr, yv, yte = split_data(df, args.seed)
    models = build_models(args.seed)
    probability_matrix(models, Xtr, ytr)  # fit only on training partition
    Pval = probability_matrix(models, Xv)
    Ptest = probability_matrix(models, Xte)
    names = list(models)
    policy = choose_policy(Pval, yv, args.review_budget, args.recall_floor,
                           args.c_fp, args.c_fn, args.c_review, args.q1, args.q0)
    if not policy["feasible"]:
        raise RuntimeError(policy["reason"] + " Adjust assumptions only with a documented protocol revision.")
    # Agent and ensemble discrimination/calibration metrics on untouched test labels.
    model_metrics = {}
    for i, name in enumerate(names):
        p = Ptest[:, i]
        model_metrics[name] = {"average_precision": float(average_precision_score(yte, p)),
            "roc_auc": float(roc_auc_score(yte, p)), "brier": float(brier_score_loss(yte, p)),
            "stratified_bootstrap_95pct": stratified_bootstrap_metrics(yte, p, args.bootstrap_repeats, args.seed)}
    pe = Ptest.mean(axis=1)
    model_metrics["mean_ensemble"] = {"average_precision": float(average_precision_score(yte, pe)),
        "roc_auc": float(roc_auc_score(yte, pe)), "brier": float(brier_score_loss(yte, pe)),
        "stratified_bootstrap_95pct": stratified_bootstrap_metrics(yte, pe, args.bootstrap_repeats, args.seed)}
    combined = simulate_final(Ptest, yte, policy, args.q1, args.q0, range(args.simulations),
                              args.c_fp, args.c_fn, args.c_review)
    baselines = {}
    for kind in ("entropy", "disagreement"):
        bp = baseline_policy(Pval, yv, kind, args.review_budget, args.recall_floor,
                             args.q1, args.q0, args.c_fp, args.c_fn, args.c_review)
        if bp["feasible"]:
            # Convert the baseline's selected signal cutoff into a test-set policy.
            sig = entropy(pe) if kind == "entropy" else Ptest.std(axis=1, ddof=0)
            review = sig >= bp["signal_threshold"]
            auto = (pe >= bp["threshold"]).astype(int)
            rows=[]
            for s in range(args.simulations):
                rng=np.random.default_rng(s)
                h=np.where(yte==1, rng.random(len(yte))<args.q1,
                           rng.random(len(yte))>=args.q0).astype(int)
                f=np.where(review,h,auto)
                cm=confusion_matrix(yte,f,labels=[0,1]).ravel()
                m=scores_from_cm(cm); m["review_rate"]=float(review.mean())
                m["cost"]=float(args.c_fp*m["fp"]+args.c_fn*m["fn"]+args.c_review*review.sum())
                rows.append(m)
            frame=pd.DataFrame(rows)
            bp["test_metrics_mean"]=frame.mean().to_dict()
            bp["test_metrics_sd"]=frame.std(ddof=1).fillna(0).to_dict()
        baselines[kind+"_only"] = bp
    # No-review ensemble baseline: choose threshold on validation by declared cost and recall.
    no_review = None
    for t in np.linspace(.01,.99,99):
        pred=(Pval.mean(axis=1)>=t).astype(int)
        cm=confusion_matrix(yv,pred,labels=[0,1]).ravel(); m=scores_from_cm(cm)
        if m["recall"] >= args.recall_floor:
            cost=args.c_fp*m["fp"]+args.c_fn*m["fn"]
            if no_review is None or cost<no_review[0]: no_review=(cost,float(t),m)
    if no_review:
        pred=(pe>=no_review[1]).astype(int)
        cm=confusion_matrix(yte,pred,labels=[0,1]).ravel()
        baselines["ensemble_no_review"]={"threshold":no_review[1],"test_metrics":scores_from_cm(cm)}
    else:
        baselines["ensemble_no_review"]={"feasible":False}
    metadata={"dataset_source":source,"dataset_sha256":dataset_fingerprint(args.data) if args.data else None,
        "rows_before_exact_deduplication":initial_rows,
        "exact_duplicate_rows_removed":duplicate_rows,"rows_after_deduplication":len(df),
        "features":list(df.drop(columns="Class").columns),"class_counts":df.Class.value_counts().sort_index().to_dict(),
        "split_rows":{"train":len(ytr),"validation":len(yv),"test":len(yte)},
        "split_fraud_counts":{"train":int(ytr.sum()),"validation":int(yv.sum()),"test":int(yte.sum())},
        "seed":args.seed,"models":names,"policy_selection":"validation only",
        "test_evaluations":1,"reviewer_simulations":args.simulations}
    result={"metadata":metadata,"policy":policy,"test_model_metrics":model_metrics,
            "combined_policy_test_simulation":combined,"baselines":baselines,
            "fixed_policy_sensitivity_on_test":fixed_policy_sensitivity(Ptest, yte, policy, args.review_budget),
            "interpretation_warning":"Reviewer outcomes are simulated from assumed sensitivity/specificity. These are not observed human-review effects."}
    (out/"results.json").write_text(json.dumps(result,indent=2,default=float))
    (out/"dataset_metadata.json").write_text(json.dumps(metadata,indent=2,default=float))
    print(json.dumps(result,indent=2,default=float))


def parse_args():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--data",default=os.getenv("CREDITCARD_DATA_PATH"))
    p.add_argument("--output",default="outputs")
    p.add_argument("--seed",type=int,default=SEED)
    p.add_argument("--review-budget",type=float,default=.10)
    p.add_argument("--recall-floor",type=float,default=.80)
    p.add_argument("--c-fp",type=float,default=1.)
    p.add_argument("--c-fn",type=float,default=10.)
    p.add_argument("--c-review",type=float,default=.5)
    p.add_argument("--q1",type=float,default=.90,help="assumed reviewer sensitivity")
    p.add_argument("--q0",type=float,default=.95,help="assumed reviewer specificity")
    p.add_argument("--simulations",type=int,default=30)
    p.add_argument("--bootstrap-repeats",type=int,default=300)
    return p.parse_args()

if __name__ == "__main__":
    run(parse_args())
