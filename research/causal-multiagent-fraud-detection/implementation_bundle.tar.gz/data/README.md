# Dataset instructions

Do not upload `creditcard.csv` to this repository.

1. Download the ULB/Worldline Credit Card Fraud Detection dataset from [Kaggle](https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud), subject to the dataset's current terms, or use OpenML data ID 1597 via the pipeline's automatic fetch option.
2. For manual download, place the extracted CSV at `data/creditcard.csv`.
3. Run `python -m src.pipeline --data data/creditcard.csv --output outputs` from this project directory.
4. Record the download date and SHA-256 fingerprint if using a local file. The pipeline records row counts and duplicate exclusions in `outputs/dataset_metadata.json`.

The OpenML route requires an internet connection. If automatic retrieval fails, download from Kaggle manually and pass `--data`.
