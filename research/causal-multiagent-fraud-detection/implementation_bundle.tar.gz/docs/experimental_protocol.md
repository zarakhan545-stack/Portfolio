# Experimental Protocol — Implementation Specification

## Research questions
1. Does inter-agent probability disagreement identify useful review cases beyond ensemble entropy?
2. Under fixed review capacity, can the combined protocol reduce declared decision cost while meeting a recall floor?
3. How sensitive are conclusions to reviewer sensitivity/specificity, cost ratios, review capacity and recall constraints?

## Data and exclusions
Use the ULB/Worldline credit-card fraud benchmark from Kaggle or OpenML data ID 1597. Record source, retrieval date, terms, checksum (for local CSV), schema, missingness, class prevalence and exact duplicate count. Exact duplicate rows are removed before splitting to reduce identical-record leakage; report pre/post row and fraud counts. Raw data must not be committed to GitHub.

## Split and leakage prevention
Use stratified 60% training, 15% validation and 25% final test with seed 42. This is a random benchmark split, not a temporal generalisation test. The dataset contains a timestamp-like `Time` feature; a chronological holdout should be added as a separate robustness protocol before claiming future-time performance. All imputers, scalers, estimators and calibration folds are fitted only within training data. Validation is used for policy selection. Test is used once for final evaluation.

## Predictive agents
1. Class-weighted Logistic Regression with median imputation and standardisation.
2. Class-weighted Random Forest with median imputation.
3. Class-weighted HistGradientBoosting with median imputation.

Each estimator is wrapped in sigmoid probability calibration with three-fold cross-validation confined to the training partition. The arithmetic mean of the calibrated probabilities is the ensemble probability. Agent disagreement is the population standard deviation of the three probabilities; entropy of the ensemble mean is a distinct comparator signal.

## Policy selection
The validation search evaluates automated threshold `t`, review interval `[l,u]` and disagreement threshold `delta`. Review is assigned when the ensemble probability is in the interval OR disagreement is at least `delta`. Select the lowest expected declared cost subject to review rate no greater than budget and expected recall no lower than the recall floor. The current implementation uses a finite quantile grid and deterministic tie-breaking. It reports infeasibility rather than silently relaxing constraints.

Expected reviewer output for a referred case is generated from assumed sensitivity `q1` and specificity `q0`, conditional on the true validation label. The true label is not an input to any predictive model or review-assignment rule. It is used only in the declared reviewer simulation and outcome evaluation.

## Cost and assumptions
`J = C_FP * FP + C_FN * FN + C_R * N_R`. Initial values (FP=1, FN=10, review=0.5), review budget 10%, recall floor 80%, reviewer sensitivity 90% and specificity 95% are illustrative. They are not empirically elicited. Run a predeclared sensitivity grid before interpretation; include weak, moderate and strong reviewer scenarios and alternative cost ratios/capacities.

## Comparators
- Each single agent (ranking/calibration metrics).
- Mean-probability ensemble without review.
- Entropy-only review.
- Disagreement-only review.
- Combined interval-or-disagreement review.

## Outcomes and uncertainty
Report average precision (PR-AUC), ROC-AUC, Brier score, precision, recall, F1, false-positive rate, confusion counts, review rate and declared cost. Report stratified bootstrap percentile intervals for ranking/calibration metrics. Repeat simulated reviewer outcomes across seeds; report mean, standard deviation and percentile interval separately. Simulation variability is not a substitute for population-sampling uncertainty.

## Reproducibility and stop/go
Save software versions, dataset fingerprint, exact row counts, split seed, assumptions, policy parameters and output JSON. Run tests before training. Inspect the final test partition only after policy freeze. If constraints are infeasible, report that outcome. Do not report numerical performance until the full real dataset has been processed and the outputs have been checked.
