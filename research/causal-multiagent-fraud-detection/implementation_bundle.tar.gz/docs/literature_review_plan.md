# Literature review plan (to complete before manuscript submission)

This is a structured search plan, not a claim that the literature review is complete.

## Search themes
1. Credit-card fraud detection under extreme class imbalance.
2. Probability calibration for rare-event classifiers.
3. Ensemble disagreement and uncertainty-based selective prediction / human review.
4. Decision-theoretic optimisation with review-capacity constraints.
5. Evaluation protocols, temporal drift and leakage in fraud datasets.
6. Causal inference versus structural causal simulation in human-in-the-loop decision systems.

## Seed sources to verify and read
- Dal Pozzolo et al., *Calibrating Probability with Undersampling for Unbalanced Classification* (2015). Verify exact venue, pages and DOI before citation.
- Carcillo et al., *Combining Unsupervised and Supervised Learning in Credit Card Fraud Detection* (Information Sciences, 2019). Verify bibliographic metadata.
- Lebichot et al., *Deep-Learning Domain Adaptation Techniques for Credit Cards Fraud Detection* (2019). Verify conference metadata.
- The ULB/Worldline dataset documentation and the Fraud Detection Handbook should be used to describe data provenance and evaluation cautions, not as substitutes for peer-reviewed methodological literature.

## Required review output
For every paper, record research question, dataset, split strategy, imbalance treatment, calibration, metrics, limitations, and the exact gap addressed by this study. Distinguish an established result from a proposed hypothesis. Confirm every DOI and citation against the publisher or Crossref before writing the manuscript.

## Gap claim to test, not assume
A defensible potential contribution is a controlled comparison of probability disagreement and ensemble entropy as review-routing signals under a fixed review-capacity and cost/recall constraint, with reviewer accuracy varied explicitly as a simulation assumption. The review must establish whether this exact combination is novel; do not claim novelty based only on a small keyword search.
